import os
import hashlib
import random
import sqlite3
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, render_template, request, jsonify, session, redirect
from flask_cors import CORS

try:
    import yfinance as yf
    YF_AVAILABLE = True
except ImportError:
    YF_AVAILABLE = False

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "stockpulse-secret-key-change-me")
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=7)
CORS(app)

DB_PATH = "stockpulse.db"
STARTING_BALANCE = 100000.0
ADMIN_USER = "admin"
ADMIN_PASS = "admin123"
ADMIN_OTP  = "123456"

STOCKS = [
    'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA',
    'TSLA', 'META', 'NFLX', 'AMD', 'INTC',
    'PYPL', 'CRM', 'BABA', 'V', 'JPM'
]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_pw(password):
    return hashlib.sha256(password.encode()).hexdigest()

def init_db():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            email TEXT UNIQUE,
            password TEXT,
            balance REAL DEFAULT 100000,
            created TEXT
        );
        CREATE TABLE IF NOT EXISTS holdings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            symbol TEXT,
            shares REAL DEFAULT 0,
            avg_cost REAL DEFAULT 0,
            UNIQUE(user_id, symbol)
        );
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            symbol TEXT,
            action TEXT,
            shares REAL,
            price REAL,
            total REAL,
            timestamp TEXT
        );
        """)
        if not conn.execute("SELECT id FROM users WHERE username='demo'").fetchone():
            conn.execute(
                "INSERT INTO users (username,email,password,balance,created) VALUES (?,?,?,?,?)",
                ("demo", "demo@stockpulse.com", hash_pw("demo123"),
                 STARTING_BALANCE, datetime.utcnow().isoformat())
            )

# =========================================================
# DECORATORS
# =========================================================

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect("/login")
        return f(*args, **kwargs)
    return wrapper

def api_login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            session.clear()
            if request.path.startswith("/api/"):
                return jsonify({"error": "Admin access required"}), 403
            return redirect("/admin/login")
        return f(*args, **kwargs)
    return wrapper

# =========================================================
# STOCK HELPERS
# =========================================================

def sim_price(symbol):
    seed = sum(ord(c) for c in symbol) + int(datetime.utcnow().strftime("%Y%m%d"))
    return round(random.Random(seed).uniform(50, 500), 2)

def get_price(symbol):
    if YF_AVAILABLE:
        try:
            hist = yf.Ticker(symbol).history(period="2d")
            if not hist.empty:
                return round(float(hist["Close"].iloc[-1]), 2)
        except Exception:
            pass
    return sim_price(symbol)

# =========================================================
# PAGE ROUTES
# =========================================================

@app.route("/")
def index():
    return render_template("home.html")

@app.route("/home")
def home_page():
    return render_template("home.html")

@app.route("/login", methods=["GET", "POST"])
def login_page():
    if request.method == "GET":
        return render_template("login.html")
    data = request.get_json() or {}
    with get_db() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (data.get("username", "").strip(), hash_pw(data.get("password", "")))
        ).fetchone()
    if not user:
        return jsonify({"success": False, "error": "Invalid credentials"})
    session.permanent = True
    session["user_id"]  = user["id"]
    session["username"] = user["username"]
    return jsonify({"success": True, "redirect": "/dashboard"})

@app.route("/register", methods=["GET", "POST"])
def register_page():
    if request.method == "GET":
        return render_template("register.html")
    data = request.get_json() or {}
    try:
        with get_db() as conn:
            conn.execute(
                "INSERT INTO users (username,email,password,balance,created) VALUES (?,?,?,?,?)",
                (data.get("username","").strip(), data.get("email","").strip(),
                 hash_pw(data.get("password","")), STARTING_BALANCE,
                 datetime.utcnow().isoformat())
            )
    except sqlite3.IntegrityError:
        return jsonify({"success": False, "error": "Username/Email already exists"})
    return jsonify({"success": True, "redirect": "/login"})

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", username=session.get("username"))

@app.route("/portfolio")
@login_required
def portfolio():
    return render_template("portfolio.html")

@app.route("/prediction")
@login_required
def prediction():
    return render_template("predict.html")

# =========================================================
# ADMIN ROUTES
# =========================================================

@app.route("/admin/login", methods=["GET"])
def admin_login_page():
    # ALWAYS clear session and force login — never skip to /admin
    session.clear()
    return render_template("admin_login.html")

@app.route("/admin")
@admin_required
def admin_page():
    return render_template("admin.html", username=session.get("username", "admin"))

# =========================================================
# ADMIN AUTH API
# =========================================================

@app.route("/api/admin/login", methods=["POST"])
def api_admin_login():
    data     = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")
    otp      = data.get("otp", "").strip()

    if username == ADMIN_USER and password == ADMIN_PASS and otp == ADMIN_OTP:
        session.clear()
        session.permanent = True
        session["admin"]    = True
        session["username"] = ADMIN_USER
        with get_db() as conn:
            row = conn.execute(
                "SELECT id FROM users WHERE username=?", (ADMIN_USER,)
            ).fetchone()
            if row:
                session["user_id"] = row["id"]
            else:
                conn.execute(
                    "INSERT OR IGNORE INTO users (username,email,password,balance,created) VALUES (?,?,?,?,?)",
                    (ADMIN_USER, "admin@stockpulse.local", hash_pw(ADMIN_PASS),
                     0.0, datetime.utcnow().isoformat())
                )
                row2 = conn.execute(
                    "SELECT id FROM users WHERE username=?", (ADMIN_USER,)
                ).fetchone()
                session["user_id"] = row2["id"] if row2 else 1
        return jsonify({"success": True, "redirect": "/admin"})

    return jsonify({"success": False, "error": "Invalid credentials or OTP"})

@app.route("/api/admin/logout", methods=["POST", "GET"])
def api_admin_logout():
    session.clear()
    return redirect("/admin/login")

# =========================================================
# ADMIN DATA APIs
# =========================================================

@app.route("/api/admin/users")
@admin_required
def api_admin_users():
    with get_db() as conn:
        users = conn.execute(
            "SELECT id,username,email,balance FROM users ORDER BY id DESC"
        ).fetchall()
        result = []
        for u in users:
            holdings = conn.execute(
                "SELECT symbol,shares FROM holdings WHERE user_id=? AND shares>0",
                (u["id"],)
            ).fetchall()
            tc = conn.execute(
                "SELECT COUNT(*) as cnt FROM trades WHERE user_id=?", (u["id"],)
            ).fetchone()["cnt"]
            result.append({
                "username":    u["username"],
                "email":       u["email"] or "",
                "balance":     round(u["balance"], 2),
                "portfolio":   {h["symbol"]: round(h["shares"],4) for h in holdings},
                "trade_count": tc,
                "is_admin":    u["username"] == ADMIN_USER
            })
    return jsonify(result)

@app.route("/api/admin/trades")
@admin_required
def api_admin_trades():
    with get_db() as conn:
        trades = conn.execute("""
            SELECT t.*, u.username FROM trades t
            JOIN users u ON u.id=t.user_id
            ORDER BY t.id DESC LIMIT 500
        """).fetchall()
    return jsonify([{
        "username": t["username"], "symbol": t["symbol"],
        "action": t["action"],    "shares": t["shares"],
        "price":  t["price"],     "total":  t["total"],
        "time":   t["timestamp"]
    } for t in trades])

@app.route("/api/admin/add_user", methods=["POST"])
@admin_required
def api_admin_add_user():
    data     = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()
    balance  = float(data.get("balance", STARTING_BALANCE))
    if not username or not password:
        return jsonify({"success": False, "error": "Username and password required"})
    try:
        with get_db() as conn:
            conn.execute(
                "INSERT INTO users (username,email,password,balance,created) VALUES (?,?,?,?,?)",
                (username, f"{username}@stockpulse.local", hash_pw(password),
                 balance, datetime.utcnow().isoformat())
            )
        return jsonify({"success": True})
    except sqlite3.IntegrityError:
        return jsonify({"success": False, "error": "User already exists"})

@app.route("/api/admin/delete_user", methods=["POST"])
@admin_required
def api_admin_delete_user():
    data     = request.get_json() or {}
    username = data.get("username", "")
    if username == ADMIN_USER:
        return jsonify({"success": False, "error": "Cannot delete admin"})
    with get_db() as conn:
        user = conn.execute(
            "SELECT id FROM users WHERE username=?", (username,)
        ).fetchone()
        if not user:
            return jsonify({"success": False, "error": "User not found"})
        uid = user["id"]
        conn.execute("DELETE FROM holdings WHERE user_id=?", (uid,))
        conn.execute("DELETE FROM trades WHERE user_id=?",   (uid,))
        conn.execute("DELETE FROM users WHERE id=?",         (uid,))
    return jsonify({"success": True})

@app.route("/api/admin/set_balance", methods=["POST"])
@admin_required
def api_admin_set_balance():
    data = request.get_json() or {}
    with get_db() as conn:
        conn.execute("UPDATE users SET balance=? WHERE username=?",
                     (float(data.get("balance", 0)), data.get("username", "")))
    return jsonify({"success": True})

# =========================================================
# USER API
# =========================================================

@app.route("/api/user")
@api_login_required
def api_user():
    with get_db() as conn:
        user = conn.execute(
            "SELECT username,balance FROM users WHERE id=?", (session["user_id"],)
        ).fetchone()
    if not user:
        return jsonify({"error": "User not found"}), 404
    return jsonify({"username": user["username"], "balance": round(user["balance"], 2)})
# =========================================================
# STOCK APIs
# =========================================================

@app.route("/api/stocks")
@api_login_required
def api_stocks():
    result = []
    for sym in STOCKS:
        price = get_price(sym)
        rng   = random.Random(sum(ord(c) for c in sym) + 99)
        prev  = round(price * rng.uniform(0.94, 1.06), 2)
        chg   = round(((price - prev) / prev) * 100, 2)
        result.append({
            "symbol": sym, "price": price,
            "previous_close": prev, "change_pct": chg, "up": price >= prev
        })
    return jsonify(result)

@app.route("/api/stock/<symbol>")
@api_login_required
def api_stock(symbol):
    price = get_price(symbol.upper())
    return jsonify({
        "symbol":     symbol.upper(),
        "price":      price,
        "change_pct": round(random.uniform(-5, 5), 2),
        "bullish":    random.choice([True, False])
    })

@app.route("/api/chart/<symbol>")
@api_login_required
def api_chart(symbol):
    try:
        hist = yf.Ticker(symbol.upper()).history(period="30d")
        return jsonify({
            "labels": [str(d.date()) for d in hist.index],
            "closes": [round(float(x), 2) for x in hist["Close"]]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# =========================================================
# TRADE API
# =========================================================

@app.route("/api/trade", methods=["POST"])
@api_login_required
def api_trade():
    data   = request.get_json() or {}
    symbol = data.get("symbol", "").upper().strip()
    action = data.get("action", "").upper().strip()
    shares = float(data.get("shares", 0))

    if not symbol or action not in ("BUY", "SELL") or shares <= 0:
        return jsonify({"success": False, "error": "Invalid trade parameters"})

    uid   = session["user_id"]
    price = get_price(symbol)
    total = round(price * shares, 2)

    with get_db() as conn:
        user = conn.execute("SELECT balance FROM users WHERE id=?", (uid,)).fetchone()
        if not user:
            return jsonify({"success": False, "error": "User not found"})
        balance = user["balance"]

        if action == "BUY":
            if total > balance:
                return jsonify({"success": False,
                                "error": f"Insufficient balance. Need ${total:.2f}, have ${balance:.2f}"})
            new_balance = round(balance - total, 2)
            existing = conn.execute(
                "SELECT shares,avg_cost FROM holdings WHERE user_id=? AND symbol=?",
                (uid, symbol)
            ).fetchone()
            if existing:
                ns = round(existing["shares"] + shares, 6)
                nc = round((existing["shares"]*existing["avg_cost"] + shares*price) / ns, 4)
                conn.execute(
                    "UPDATE holdings SET shares=?,avg_cost=? WHERE user_id=? AND symbol=?",
                    (ns, nc, uid, symbol)
                )
            else:
                conn.execute(
                    "INSERT INTO holdings (user_id,symbol,shares,avg_cost) VALUES (?,?,?,?)",
                    (uid, symbol, round(shares,6), round(price,4))
                )
        else:  # SELL
            existing = conn.execute(
                "SELECT shares FROM holdings WHERE user_id=? AND symbol=?",
                (uid, symbol)
            ).fetchone()
            held = existing["shares"] if existing else 0
            if held < shares:
                return jsonify({"success": False,
                                "error": f"Not enough shares. You hold {held:.4f} {symbol}"})
            new_balance = round(balance + total, 2)
            ns = round(held - shares, 6)
            if ns < 0.0001:
                conn.execute("DELETE FROM holdings WHERE user_id=? AND symbol=?", (uid, symbol))
            else:
                conn.execute("UPDATE holdings SET shares=? WHERE user_id=? AND symbol=?",
                             (ns, uid, symbol))

        conn.execute("UPDATE users SET balance=? WHERE id=?", (new_balance, uid))
        conn.execute(
            "INSERT INTO trades (user_id,symbol,action,shares,price,total,timestamp) VALUES (?,?,?,?,?,?,?)",
            (uid, symbol, action, shares, price, total, datetime.utcnow().isoformat())
        )

    return jsonify({"success": True, "price": price, "total": total, "new_balance": new_balance})

# =========================================================
# PORTFOLIO API
# =========================================================

@app.route("/api/portfolio")
@api_login_required
def api_portfolio():
    uid = session["user_id"]
    with get_db() as conn:
        holdings = conn.execute(
            "SELECT symbol,shares,avg_cost FROM holdings WHERE user_id=? AND shares>0", (uid,)
        ).fetchall()
        user = conn.execute("SELECT balance FROM users WHERE id=?", (uid,)).fetchone()

    result = []
    for h in holdings:
        cp  = get_price(h["symbol"])
        cb  = round(h["avg_cost"] * h["shares"], 2)
        mv  = round(cp * h["shares"], 2)
        pnl = round(mv - cb, 2)
        result.append({
            "symbol":        h["symbol"],
            "shares":        round(h["shares"], 4),
            "avg_cost":      round(h["avg_cost"], 2),
            "current_price": cp,
            "cost_basis":    cb,
            "market_value":  mv,
            "pnl":           pnl,
            "pnl_pct":       round((pnl/cb)*100, 2) if cb else 0
        })
    return jsonify({"holdings": result, "cash": round(user["balance"], 2) if user else 0})

# =========================================================
# ERROR HANDLERS
# =========================================================

@app.errorhandler(404)
def not_found(e):
    return "<h1>404 – Page Not Found</h1>", 404

@app.errorhandler(500)
def server_error(e):
    return "<h1>500 – Internal Server Error</h1>", 500

# =========================================================
# RUN
# =========================================================

if __name__ == "__main__":
    init_db()
    print("=" * 44)
    print("  StockPulse  →  http://127.0.0.1:5000")
    print("  Demo user   :  demo / demo123")
    print("  Admin login :  /admin/login")
    print("  Credentials :  admin / admin123 / 123456")
    print("=" * 44)
    app.run(debug=True, host="0.0.0.0", port=5000)