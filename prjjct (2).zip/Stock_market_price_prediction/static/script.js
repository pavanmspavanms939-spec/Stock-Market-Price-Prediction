// ── Ticker tape ──
const stocks = [
  {sym:'AAPL',price:189.42,chg:+1.23},
  {sym:'MSFT',price:412.85,chg:+2.61},
  {sym:'GOOGL',price:178.30,chg:-0.84},
  {sym:'AMZN',price:194.15,chg:+3.10},
  {sym:'NVDA',price:875.40,chg:+12.30},
  {sym:'TSLA',price:248.50,chg:-4.20},
  {sym:'META',price:521.00,chg:+5.75},
  {sym:'NFLX',price:628.90,chg:+1.98},
  {sym:'AMD',price:162.30,chg:-2.10},
  {sym:'INTC',price:43.85,chg:+0.45},
  {sym:'PYPL',price:67.20,chg:-0.95},
  {sym:'CRM',price:290.10,chg:+3.20},
];

function buildTicker() {
  const track = document.getElementById('ticker-track');
  const doubled = [...stocks, ...stocks]; // duplicate for seamless loop
  track.innerHTML = doubled.map(s => `
    <div class="ticker-item">
      <span class="t-sym">${s.sym}</span>
      <span class="t-price">$${s.price.toFixed(2)}</span>
      <span class="t-chg ${s.chg>=0?'up':'dn'}">${s.chg>=0?'+':''}${s.chg.toFixed(2)}%</span>
    </div>
  `).join('');
}
buildTicker();

// ── Animate stat numbers ──
function animateNumber(el, target, prefix='', suffix='', decimals=0) {
  let start = 0;
  const duration = 1800;
  const step = (timestamp) => {
    if (!start) start = timestamp;
    const progress = Math.min((timestamp - start) / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const current = ease * target;
    el.textContent = prefix + current.toFixed(decimals) + suffix;
    if (progress < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

// Trigger when stats section comes into view
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const boxes = entry.target.querySelectorAll('.stat-num');
      const data = [
        {val:94.7, prefix:'', suffix:'%', dec:1},
        {val:500,  prefix:'', suffix:'+', dec:0},
        {val:50,   prefix:'', suffix:'K+', dec:0},
        {val:2.1,  prefix:'$', suffix:'B', dec:1},
      ];
      boxes.forEach((box, i) => {
        animateNumber(box, data[i].val, data[i].prefix, data[i].suffix, data[i].dec);
      });
      observer.disconnect();
    }
  });
}, {threshold: 0.3});
const statsSection = document.querySelector('.stats-section');
if (statsSection) observer.observe(statsSection);
